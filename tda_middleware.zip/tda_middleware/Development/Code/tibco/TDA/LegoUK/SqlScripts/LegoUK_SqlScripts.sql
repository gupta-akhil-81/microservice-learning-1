--Create  audit table
drop table "TIBCO_AUDITLOGS" ;
CREATE TABLE "TIBCO_AUDITLOGS" 
   (	"UNIQUEKEY" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	"CORRELATIONID" VARCHAR2(100 BYTE), 
	"TIME_STAMP" VARCHAR2(40 BYTE), 
	"ELAPSED_TIME" NUMBER,
	"SERVICE_NAME" VARCHAR2(200 BYTE), 
	"OPERATION_NAME" VARCHAR2(150 BYTE), 
	"MESSAGE" VARCHAR2(2000 BYTE), 
	"PAYLOAD" CLOB
   );
   commit;
=================================================================================================================================================================================================
--Create Exception table

drop table "TIBCO_EXCEPTIONLOGS";
CREATE TABLE "TIBCO_EXCEPTIONLOGS" 
   (	"UNIQUEKEY" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	"CORRELATIONID" VARCHAR2(100 BYTE), 
	"TIME_STAMP" VARCHAR2(40 BYTE), 
	"SERVICE_NAME" VARCHAR2(200 BYTE), 
	"OPERATION_NAME" VARCHAR2(150 BYTE), 
	"ERROR_CODE" VARCHAR2(40 BYTE), 
	"ERROR_MESSAGE" VARCHAR2(2000 BYTE), 
	"STACK_TRACE" CLOB, 
	"ERROR_REASON" VARCHAR2(2000 BYTE), 
	"PAYLOAD" CLOB
   );
   commit;
=================================================================================================================================================================================================
-- Cache cache manager table

 drop table "CACHE_MANAGER" ;
 CREATE TABLE "CACHE_MANAGER" 
   (	"TYPE" VARCHAR2(30 BYTE) NOT NULL ENABLE, 
	"APP_LOCALE" VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	"KEY" VARCHAR2(255 BYTE) NOT NULL ENABLE, 
	"ETAG" VARCHAR2(255 BYTE), 
	"CREATED" VARCHAR2(30 BYTE), 
	"MODIFIED" VARCHAR2(30 BYTE), 
	"EXPIRES" VARCHAR2(30 BYTE), 
	"CONTENT" CLOB,
	 CONSTRAINT "CACHE_MANAGER_PK" PRIMARY KEY ("TYPE", "KEY"));
	 commit;
=================================================================================================================================================================================================
-- Cache Session Manager table	 
	 
drop sequence SESSIONIDSEQ;
drop table "SM_SESSION_RESOURCE" ;
drop table "SM_SESSION" ;

 create sequence SESSIONIDSEQ 
start with 1 
increment by 1 
nomaxvalue;
   
CREATE TABLE "SM_SESSION" 
   (	"ID" NUMBER(10,0) NOT NULL ENABLE, 
	"SID" VARCHAR2(255 BYTE) NOT NULL ENABLE,
	"CREATED" TIMESTAMP (6), 
	"EXPIRES" TIMESTAMP (6), 
	"CLIENT_INFO" VARCHAR2(255 BYTE), 
	"FULLNAME" VARCHAR2(255 BYTE),
	"HOMETELE" VARCHAR2(15 BYTE),
	"COMPTELE" VARCHAR2(15 BYTE),
	"MOBILE" VARCHAR2(15 BYTE),
	"EMAIL" VARCHAR2(255 BYTE),
	 PRIMARY KEY ("ID"),
	  UNIQUE ("SID")
	  );	
	  
	 CREATE TABLE "SM_SESSION_RESOURCE" 
   (	"ID" NUMBER(10,0) NOT NULL ENABLE, 
	"RESOURCE_URL" VARCHAR2(512 BYTE) NOT NULL ENABLE, 
	 CONSTRAINT "SM_SESSION_RESOURCE_PK" PRIMARY KEY ("ID", "RESOURCE_URL"),
  	 CONSTRAINT "SM_SESSION_RESOURCE_SM_SE_FK1" FOREIGN KEY ("ID")
	  REFERENCES "SM_SESSION" ("ID") ENABLE
   )  ;
   
  commit; 
=================================================================================================================================================================================================
-- Resource TTL data
drop table "RESOURCE_TTL" ;
CREATE TABLE "RESOURCE_TTL" 
   (	"TTL" VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	"RESOURCE_NAME" VARCHAR2(100 BYTE));
-- INSERT SCRIPT --
REM INSERTING into RESOURCE_TTL
SET DEFINE OFF;
  commit; 
  
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('1800','DS-BOOKING');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('1800','BOOKINGBYID');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('86400','DS-ACCOMODATION');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('86400','DS-AIRPORT');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('86400','DS-LOCATION'); 
commit;
=================================================================================================================================================================================================
--------------------------------------------------------
--  DDL for Table STATIC_TEXT
--------------------------------------------------------
	DROP TABLE STATIC_TEXT;
  CREATE TABLE "STATIC_TEXT" 
   (	"KEY" VARCHAR2(200 BYTE), 
	"LANG" VARCHAR2(5 BYTE) DEFAULT '*', 
	"COUNTRY" VARCHAR2(5 BYTE) DEFAULT '*', 
	"TEXT" VARCHAR2(1000 BYTE), 
	"CREATED_TS" TIMESTAMP (6), 
	"CHANGED_TS" TIMESTAMP (6)
   ) ;
REM INSERTING into STATIC_TEXT
SET DEFINE OFF;
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_contactPhone_url_th','en','GB','0203 451 2688',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_contactMail_url_th','en','GB','http://www.thomson.co.uk/editorial/send-us-an-email-confBooking.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_retail_link_linkPrivacy_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_retail_link_linkPrivacy_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/privacy-policy.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_retail_link_linkTerm_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_retail_link_linkTerm_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/booking-terms-and-conditions.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_linkTerm_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_linkTerm_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/booking-terms-and-conditions.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_linkPrivacy_url_fc','en','GB','https://www.firstchoice.co.uk/our-policies/privacy-policy/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_linkPrivacy_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/privacy-policy.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_contactPhone_url','en','GB','0844 871 0878',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_contactMail_url','en','GB','MyThomsonOnline@thomson.co.uk',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_linkTerm_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_linkTerm_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/booking-terms-and-conditions.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_linkPrivacy_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_duringHoliday_link_linkPrivacy_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/privacy-policy.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_link_contactPhone_url','en','GB','0203 451 2693',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_link_linkTerm_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_link_linkTerm_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/booking-terms-and-conditions.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_link_linkPrivacy_url_fc','en','GB','http://www.firstchoice.co.uk/our-policies/my-first-choice-terms-and-conditions/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_link_linkPrivacy_url_th','en','GB','http://www.thomson.co.uk/editorial/legal/privacy-policy.html',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_postHoliday_openingHours','en','GB','9am-5.00pm|9am-5.00pm|9am-5.00pm|9am-5.00pm|9am-5.00pm|Closed|Closed',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_openingHours','en','GB','8am-8:00pm|8am-8:00pm|8am-8:00pm|8am-8:00pm|8am-8:00pm|9am-6:00pm|10am-5:00pm',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_contactPhone_url_fc','en','GB','0203 451 2720',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_preHoliday_nonRetail_link_contactMail_url_fc','en','GB','http://www.firstchoice.co.uk/contact-us/',to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('16-FEB-16 12.00.00.000000000 AM','DD-MON-RR HH.MI.SSXFF AM'));
commit;
--------------------------------------------
----Retail List Create script-----------------
  DROP TABLE "RETAIL_LIST";
  CREATE TABLE "RETAIL_LIST" 
   (	"SALESDIVISION" VARCHAR2(50 BYTE), 
	"DIVISIONALSALESMANAGER" VARCHAR2(50 BYTE), 
	"SALESREGIONS" VARCHAR2(50 BYTE), 
	"SHOPNAME" VARCHAR2(50 BYTE), 
	"SHOPNO" VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	"SHOPGRADE" VARCHAR2(20 BYTE), 
	"NEW_TRANS_REFIT_REBRAND_OTHER" VARCHAR2(50 BYTE), 
	"EFFECTIVEDATE" VARCHAR2(200 BYTE), 
	"BUSINESSTRANSFERREDFROM" VARCHAR2(100 BYTE), 
	"WEBFRIENDLYSHOPNAME" VARCHAR2(100 BYTE), 
	"BRAND" VARCHAR2(20 BYTE), 
	"ABTA_NO" VARCHAR2(20 BYTE), 
	"LOCATIONTYPE" VARCHAR2(20 BYTE), 
	"ADDRESS1" VARCHAR2(200 BYTE), 
	"ADDRESS2" VARCHAR2(200 BYTE), 
	"TOWN" VARCHAR2(50 BYTE), 
	"COUNTY" VARCHAR2(50 BYTE), 
	"COUNTRY" VARCHAR2(50 BYTE), 
	"POSTCODE" VARCHAR2(10 BYTE), 
	"TEL" VARCHAR2(20 BYTE), 
	"NUMBER_0844_0845" VARCHAR2(20 BYTE), 
	"FX_DB" VARCHAR2(20 BYTE), 
	"CRUISE_LOUNGE_DESK_SHOP" VARCHAR2(50 BYTE), 
	"VCC" VARCHAR2(20 BYTE), 
	"THOMSONDIRECT" VARCHAR2(20 BYTE), 
	"THOMSONOFFLINE" VARCHAR2(20 BYTE), 
	"FIRSTCHOICEDIRECT" VARCHAR2(20 BYTE), 
	"FIRSTCHOICEOFFLINE" VARCHAR2(20 BYTE), 
	"CRUISEDEALS" VARCHAR2(20 BYTE), 
	"OPENSUNDAYSALLYEAR" VARCHAR2(30 BYTE), 
	"OPENINGHOURSMON" VARCHAR2(30 BYTE), 
	"OPENINGHOURSTUE" VARCHAR2(30 BYTE), 
	"OPENINGHOURSWED" VARCHAR2(30 BYTE), 
	"OPENINGHOURSTHUR" VARCHAR2(30 BYTE), 
	"OPENINGHOURSFRI" VARCHAR2(30 BYTE), 
	"OPENINGHOURSSAT" VARCHAR2(30 BYTE), 
	"OPENINGHOURSSUN" VARCHAR2(30 BYTE), 
	"SHOPEMAIL" VARCHAR2(100 BYTE), 
	"SHOPMANAGEREMAIL" VARCHAR2(100 BYTE), 
	"INSTORERADIO" VARCHAR2(20 BYTE), 
	"FOOTFALLCOUNTER" VARCHAR2(20 BYTE)
   ); 
   commit;

	 
--------------------------------------------------------
--  DDL for Table BOOKINGBRANDS
--------------------------------------------------------
	DROP TABLE BOOKINGBRANDS;
  CREATE TABLE "BOOKINGBRANDS" 
   (	"BRAND" VARCHAR2(40 BYTE), 
	"SUBBRANDS" VARCHAR2(40 BYTE)
   ) ;
REM INSERTING into BOOKINGBRANDS
SET DEFINE OFF;
Insert into BOOKINGBRANDS (BRAND,SUBBRANDS) values ('THOMSON','SK;SM;VL;RB;TH');
Insert into BOOKINGBRANDS (BRAND,SUBBRANDS) values ('FIRSTCHOICE','FC');
Insert into BOOKINGBRANDS (BRAND,SUBBRANDS) values ('FALCON','FN;FS;TI');
Insert into BOOKINGBRANDS (BRAND,SUBBRANDS) values ('INCLUDED','SK;SM;VL;RB;TH;FN;FS;TI;FC;FO');
commit;