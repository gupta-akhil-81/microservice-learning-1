update STATIC_TEXT SET TEXT ='http://Cars.cartrawler.com/startour/no/?clientId=642874' WHERE KEY = 'mw_screen_ancillary_destination_carhire_link_url' AND LANG = 'nn' AND COUNTRY ='NO';
update STATIC_TEXT SET TEXT ='http://Cars.cartrawler.com/fritidsresor/?clientId=642840' WHERE KEY = 'mw_screen_ancillary_destination_carhire_link_url' AND LANG = '*' AND COUNTRY ='*';
update STATIC_TEXT SET TEXT ='http://Cars.cartrawler.com/fritidsresor/?clientId=642840' WHERE KEY = 'mw_screen_ancillary_destination_carhire_link_url' AND LANG = 'sv' AND COUNTRY ='SE';
update STATIC_TEXT SET TEXT ='http://Cars.cartrawler.com/startour/da/?clientId=642891' WHERE KEY = 'mw_screen_ancillary_destination_carhire_link_url' AND LANG = 'da' AND COUNTRY ='DK';
update STATIC_TEXT SET TEXT ='http://Cars.cartrawler.com/finnmatkat/?clientId=642857' WHERE KEY = 'mw_screen_ancillary_destination_carhire_link_url' AND LANG = 'fi' AND COUNTRY ='FI';

--Resouce TTL of remaining Data Service and BookingByID
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETROOMDETAILS'); 
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETDESTINATION');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETPACKAGEPRODUCTCONFIG');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETPRODUCTDESTINATIONCONFIG');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('1800','BOOKINGBYID'); 