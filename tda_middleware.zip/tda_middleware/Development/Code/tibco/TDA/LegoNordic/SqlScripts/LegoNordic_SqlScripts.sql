--Create  audit table
drop table "TIBCO_AUDITLOGS" ;
CREATE TABLE "TIBCO_AUDITLOGS" 
   (	"UNIQUEKEY" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	"CORRELATIONID" VARCHAR2(100 BYTE), 
	"TIME_STAMP" VARCHAR2(40 BYTE), 
	"ELAPSED_TIME" NUMBER,
	"SERVICE_NAME" VARCHAR2(200 BYTE), 
	"OPERATION_NAME" VARCHAR2(150 BYTE), 
	"MESSAGE" VARCHAR2(2000 BYTE), 
	"PAYLOAD" CLOB
   );
   commit;

--Create Exception table

drop table "TIBCO_EXCEPTIONLOGS";
CREATE TABLE "TIBCO_EXCEPTIONLOGS" 
   (	"UNIQUEKEY" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	"CORRELATIONID" VARCHAR2(100 BYTE), 
	"TIME_STAMP" VARCHAR2(40 BYTE), 
	"SERVICE_NAME" VARCHAR2(200 BYTE), 
	"OPERATION_NAME" VARCHAR2(150 BYTE), 
	"ERROR_CODE" VARCHAR2(40 BYTE), 
	"ERROR_MESSAGE" VARCHAR2(2000 BYTE), 
	"STACK_TRACE" CLOB, 
	"ERROR_REASON" VARCHAR2(2000 BYTE), 
	"PAYLOAD" CLOB
   );
   commit;

-- Cache cache manager table

 drop table "CACHE_MANAGER" ;
 CREATE TABLE "CACHE_MANAGER" 
   (	"TYPE" VARCHAR2(30 BYTE) NOT NULL ENABLE, 
	"APP_LOCALE" VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	"KEY" VARCHAR2(255 BYTE) NOT NULL ENABLE, 
	"ETAG" VARCHAR2(255 BYTE), 
	"CREATED" VARCHAR2(30 BYTE), 
	"MODIFIED" VARCHAR2(30 BYTE), 
	"EXPIRES" VARCHAR2(30 BYTE), 
	"CONTENT" CLOB,
	 CONSTRAINT "CACHE_MANAGER_PK" PRIMARY KEY ("TYPE", "KEY"));
	 commit;

	 
-- Cache Session Manager table	 
	 
drop sequence SESSIONIDSEQ;
drop table "SM_SESSION_RESOURCE" ;
drop table "SM_SESSION" ;

 create sequence SESSIONIDSEQ 
start with 1 
increment by 1 
nomaxvalue;
   

CREATE TABLE "SM_SESSION" 
   (	"ID" NUMBER(10,0) NOT NULL ENABLE, 
	"SID" VARCHAR2(255 BYTE) NOT NULL ENABLE,
	"CREATED" TIMESTAMP (6), 
	"EXPIRES" TIMESTAMP (6), 
	"CLIENT_INFO" VARCHAR2(255 BYTE), 
	"FULLNAME" VARCHAR2(255 BYTE),
	"HOMETELE" VARCHAR2(15 BYTE),
	"COMPTELE" VARCHAR2(15 BYTE),
	"MOBILE" VARCHAR2(15 BYTE),
	"EMAIL" VARCHAR2(255 BYTE),
	 PRIMARY KEY ("ID"),
	  UNIQUE ("SID")
	  )
	  ;
	  
	
	  
	 CREATE TABLE "SM_SESSION_RESOURCE" 
   (	"ID" NUMBER(10,0) NOT NULL ENABLE, 
	"RESOURCE_URL" VARCHAR2(512 BYTE) NOT NULL ENABLE, 
	 CONSTRAINT "SM_SESSION_RESOURCE_PK" PRIMARY KEY ("ID", "RESOURCE_URL"),
  	 CONSTRAINT "SM_SESSION_RESOURCE_SM_SE_FK1" FOREIGN KEY ("ID")
	  REFERENCES "SM_SESSION" ("ID") ENABLE
   )  ;
   
  commit; 
   
-- Resource TTL data
drop table "RESOURCE_TTL" ;
CREATE TABLE "RESOURCE_TTL" 
   (	"TTL" VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	"RESOURCE_NAME" VARCHAR2(100 BYTE));
-- INSERT SCRIPT --
REM INSERTING into RESOURCE_TTL
SET DEFINE OFF;
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','CRS');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETRESORT');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETACCOMMODATIONPRODUCT');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('3600','GETWEATHER');
Insert into RESOURCE_TTL (TTL,RESOURCE_NAME) values ('21600','GETIMAGES'); 
  commit; 
   


drop table "STATIC_TEXT" ;
CREATE TABLE STATIC_TEXT
   (	"KEY" VARCHAR2(200 BYTE), 
	"LANG" VARCHAR2(5 BYTE) DEFAULT '*', 
	"COUNTRY" VARCHAR2(5 BYTE) DEFAULT '*', 
	"TEXT" VARCHAR2(1000 BYTE), 
	"CREATED_TS" TIMESTAMP (6), 
	"CHANGED_TS" TIMESTAMP (6)
   );
   CREATE UNIQUE INDEX STATICTEXT_PK ON STATIC_TEXT ("KEY", "LANG", "COUNTRY");
   ALTER TABLE STATIC_TEXT ADD CONSTRAINT "STATICTEXT_PK" PRIMARY KEY ("KEY", "LANG", "COUNTRY");
   ALTER TABLE STATIC_TEXT MODIFY ("KEY" NOT NULL ENABLE);

  ALTER TABLE STATIC_TEXT MODIFY ("LANG" NOT NULL ENABLE);

  ALTER TABLE STATIC_TEXT MODIFY ("COUNTRY" NOT NULL ENABLE);

  ALTER TABLE STATIC_TEXT  MODIFY ("CREATED_TS" NOT NULL ENABLE);

  ALTER TABLE STATIC_TEXT MODIFY ("CHANGED_TS" NOT NULL ENABLE);
   commit;

drop table "TIMS_ERROR_MAPPING" ;
CREATE TABLE "TIMS_ERROR_MAPPING" 
   (	"HTTP_STATUS" VARCHAR2(3 BYTE) NOT NULL ENABLE, 
	"ERROR_CODE" VARCHAR2(100 BYTE) NOT NULL ENABLE, 
	"DESCRIPTION" VARCHAR2(2000 BYTE)
   );
   -- INSERT SCRIPT --
REM INSERTING into TIMS_ERROR_MAPPING
SET DEFINE OFF;
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('404','HTTP_CLIENT_ERROR','There is no function or resource at the requested URL');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('405','HTTP_CLIENT_ERROR','HTTP method (POST, GET etc) not supported');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('415','HTTP_CLIENT_ERROR','The request content type has to be application/json');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('400','MALFORMED_REQUEST_BODY','The request body content is not valid JSON');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('400','INVALID_REQUEST_DATA','The structure of the request is valid, but the actual data is not');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('401','AUTHENTICATION_REQUIRED','Anonymous access is not allowed, or attempted authentication method is not supported');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('401','AUTHENTICATION_FAILED','Unknown user or wrong password');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('401','NOT_AUTHORIZED','Authentication was successful, but user lacks sufficient privileges');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('500','HTTP_SERVER_ERROR','Unexpected error condition. The client should inform the user that the service is unavailable for the time being.');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('400','PROTOCOL_NOT_FOUND','PROTOCOL_NOT_FOUND');
Insert into TIMS_ERROR_MAPPING (HTTP_STATUS,ERROR_CODE,DESCRIPTION) values ('400','MS_ISDN_NOT_FOUND','There is no user with the specified MS-ISDN.');
commit;
--Middleware Static Keys --
REM INSERTING into STATIC_TEXT
SET DEFINE OFF;
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_doc_text_productDetails_hotel_dynInformation','*','*','internet;miscellaneous',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactMail_url','sv','SE','info@fritidsresor.se',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactMail_url','da','DK','kontakt@startour.dk',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactMail_url','fi','FI','myynti@finnmatkat.fi',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactMail_url','nn','NO','kundeservice@startour.no',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactPhone_url','sv','SE','+46771840100',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactPhone_url','da','DK','+4570101050',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactPhone_url','fi','FI','+35830360640',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_contactPhone_url','nn','NO','+4767115100',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkPrivacy_url','sv','SE','http://www.fritidsresor.se/Om-Fritidsresor/Integritet-och-sakerhet/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkPrivacy_url','da','DK','http://www.startour.dk/Om-Star-Tour/cookies-og-sikkerhed/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkPrivacy_url','fi','FI','http://www.finnmatkat.fi/Tietoa-Finnmatkoista/rekisteriseloste-ja-tietosuoja/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkPrivacy_url','nn','NO','http://www.startour.no/om-star-tour/personvern-og-sikkerhet/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkTerm_url','sv','SE','http://www.fritidsresor.se/Att-resa-med-oss/Resevillkor/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkTerm_url','da','DK','http://www.startour.dk/rejse-med-Star-Tour/Rejsevilkaar/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkTerm_url','fi','FI','http://www.finnmatkat.fi/Hyva-tietaa/Matkaehdot/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_contactUs_link_linkTerm_url','nn','NO','http://www.startour.no/reise-med-star-tour/reisevilkar/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_doc_text_productDetails_hotel_dynFactGroups','*','*','distance',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_doc_text_destination_info_general_facts','*','*','currency_and_creditcard;timezone_difference;transportation',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_link_url','*','*','http://www.fritidsresor.se/Att-resa-med-oss/Flyginformation/Taxfree/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_link_url','sv','SE','http://www.fritidsresor.se/Att-resa-med-oss/Flyginformation/Taxfree/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_link_url','da','DK','http://www.startour.dk/rejse-med-Star-Tour/Flyinformation/Taxfree/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_link_url','fi','FI','http://www.finnmatkat.fi/Hyva-tietaa/Lentomatka/Taxfree/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_link_url','nn','NO','http://www.startour.no/reise-med-star-tour/fly-informasjon/Taxfree/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_deeplink_defaultUrl','nn','NO','http://www.startour.no/reise-med-star-tour/pa-reisemalet/utflukter/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_deeplink_defaultUrl','fi','FI','http://www.finnmatkat.fi/hyva-tietaa/ennen-matkaa/lisapalvelut/retket/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_deeplink_defaultUrl','sv','SE','http://www.fritidsresor.se/resor/utflykter-och-sightseeing/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_deeplink_defaultUrl','da','DK','http://www.startour.dk/rejse-med-star-tour/paa-rejsemaalet/ankomsten/',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_image_url','sv','SE','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_image_url','da','DK','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_image_url','fi','FI','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_dutyfree_image_url','nn','NO','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_imageUrl','sv','SE','http://images.tuinordic.com/travel/images/TDA/I_0256308_excursion.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_imageUrl','da','DK','http://images.tuinordic.com/travel/images/TDA/I_0256308_excursion.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_imageUrl','fi','FI','http://images.tuinordic.com/travel/images/TDA/I_0256308_excursion.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_excursion_imageUrl','nn','NO','http://images.tuinordic.com/travel/images/TDA/I_0256308_excursion.jpg',to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('18-JAN-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
INSERT INTO STATIC_TEXT (KEY, LANG, COUNTRY, TEXT, CREATED_TS, CHANGED_TS) VALUES ('mw_doc_xml_contactUs_openingHours','sv','SE','<?xml version="1.0" encoding="UTF-8"?>
<openingHours>
  <title>Telefonöppet:</title>
  <hours><dayOfWeek>Måndag–torsdag</dayOfWeek>   <from>8</from><to>22</to></hours>
  <hours><dayOfWeek>Fredag</dayOfWeek>   <from>8</from><to>19</to></hours>
  <hours><dayOfWeek>Lördag</dayOfWeek> <from>9</from><to>18</to></hours>
  <hours><dayOfWeek>Söndag</dayOfWeek>   <from>9</from><to>22</to></hours>
</openingHours>',TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'),TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'));
INSERT INTO STATIC_TEXT (KEY, LANG, COUNTRY, TEXT, CREATED_TS, CHANGED_TS) VALUES ('mw_doc_xml_contactUs_openingHours','da','DK','<?xml version="1.0" encoding="UTF-8"?>
<openingHours>
  <title>Telefonåbent:</title>
  <hours><dayOfWeek>Mandag–torsdag</dayOfWeek>   <from>8</from><to>22</to></hours>
  <hours><dayOfWeek>Fredag</dayOfWeek>   <from>8</from><to>19</to></hours>
  <hours><dayOfWeek>Lørdag</dayOfWeek> <from>9</from><to>18</to></hours>
  <hours><dayOfWeek>Søndag</dayOfWeek>   <from>9</from><to>22</to></hours>
</openingHours>',TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'),TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'));
INSERT INTO STATIC_TEXT (KEY, LANG, COUNTRY, TEXT, CREATED_TS, CHANGED_TS) VALUES ('mw_doc_xml_contactUs_openingHours','fi','FI','<?xml version="1.0" encoding="UTF-8"?>
<openingHours>
  <title>Puhelinpalvelu:</title>
  <hours><dayOfWeek>Maanantai–torstai </dayOfWeek>   <from>8</from><to>22</to></hours>
  <hours><dayOfWeek>Perjantai</dayOfWeek>   <from>8</from><to>19</to></hours>
  <hours><dayOfWeek>Lauantai</dayOfWeek> <from>9</from><to>18</to></hours>
  <hours><dayOfWeek>Sunnuntai</dayOfWeek>   <from>9</from><to>22</to></hours>
</openingHours>',TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'),TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'));
INSERT INTO STATIC_TEXT (KEY, LANG, COUNTRY, TEXT, CREATED_TS, CHANGED_TS) VALUES ('mw_doc_xml_contactUs_openingHours','nn','NO','<?xml version="1.0" encoding="UTF-8"?>
<openingHours>
  <title>Åpningstider:</title>
  <hours><dayOfWeek>Mandag–torsdag</dayOfWeek>   <from>8</from><to>22</to></hours>
  <hours><dayOfWeek>Fredag</dayOfWeek>   <from>8</from><to>19</to></hours>
  <hours><dayOfWeek>Lørdag</dayOfWeek> <from>9</from><to>18</to></hours>
  <hours><dayOfWeek>Søndag</dayOfWeek>   <from>9</from><to>22</to></hours>
</openingHours>',TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'),TO_TIMESTAMP('21-JANUARY-16 09.01.07.677000000 AM', 'DD-MON-RR HH.MI.SS.FF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_http_service_unavailable','*','*','TIMS Service is currently unavailable.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_authentication_failed','*','*','Unknown user or wrong password or insufficient privileges.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_client_forbidden','*','*','The client has been blocked from the TIMS system.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_http_client_error','*','*','Error in making client connection to the TIMS server.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_invalid_request','*','*','Either request data or data format is invalid.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_msisdn_not_found','*','*','There is no user with the specified MS-ISDN in TIMS system.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_guideOnline_error_msg_protocol_not_found','*','*','Protocol not found.',to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('24-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_image_url','sv','SE','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_image_url','da','DK','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_image_url','fi','FI','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_image_url','nn','NO','http://images.tuinordic.com/travel/images/TDA/Taxfree.jpg',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_link_url','*','*','http://www.fritidsresor.se/Att-resa-med-oss/Flyginformation/Taxfree/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_link_url','sv','SE','http://www.fritidsresor.se/Att-resa-med-oss/Flyginformation/Taxfree/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_link_url','da','DK','http://www.startour.dk/rejse-med-Star-Tour/Flyinformation/Taxfree/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_link_url','fi','FI','http://www.finnmatkat.fi/Hyva-tietaa/Lentomatka/Taxfree/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_dutyfree_link_url','nn','NO','http://www.startour.no/reise-med-star-tour/fly-informasjon/Taxfree/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_airport_hotel_link_url','*','*','https://www.nordicchoicehotels.se/tui',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_airport_hotel_link_url','sv','SE','https://www.nordicchoicehotels.se/tui',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_airport_hotel_link_url','da','DK','https://www.nordicchoicehotels.dk/tui',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_airport_hotel_link_url','nn','NO','https://www.nordicchoicehotels.no/tui',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_meals_link_url','*','*','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_meals_link_url','sv','SE','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_meals_link_url','da','DK','+4533479003',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_meals_link_url','fi','FI','+35830360628',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_flight_meals_link_url','nn','NO','+4767115022',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_airport_transfer_link_url','*','*','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_airport_transfer_link_url','sv','SE','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_airport_transfer_link_url','da','DK','+4533479003',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_airport_transfer_link_url','fi','FI','+35830360628',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_airport_transfer_link_url','nn','NO','+4767115022',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_room_upgrade_link_url','*','*','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_room_upgrade_link_url','sv','SE','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_room_upgrade_link_url','da','DK','+4533479003',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_room_upgrade_link_url','fi','FI','+35830360628',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_room_upgrade_link_url','nn','NO','+4767115022',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_hotel_meals_link_url','*','*','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_hotel_meals_link_url','sv','SE','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_hotel_meals_link_url','da','DK','+4533479003',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_hotel_meals_link_url','fi','FI','+35830360628',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_hotel_meals_link_url','nn','NO','+4767115022',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_travel_insurance_link_url','*','*','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_travel_insurance_link_url','sv','SE','+46852757598',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_travel_insurance_link_url','da','DK','+4533479003',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_travel_insurance_link_url','fi','FI','+35830360628',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_travel_insurance_link_url','nn','NO','+4767115022',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_carhire_link_url','*','*','Cars.cartrawler.com/fritidsresor/?clientId=642840',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_carhire_link_url','sv','SE','Cars.cartrawler.com/fritidsresor/?clientId=642840',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_carhire_link_url','da','DK','Cars.cartrawler.com/startour/da/?clientId=642891',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_carhire_link_url','fi','FI','Cars.cartrawler.com/finnmatkat/?clientId=642857',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_destination_carhire_link_url','nn','NO','Cars.cartrawler.com/startour/no/?clientId=642874',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_bluecard_link_url','*','*','http://www.fritidsresor.se/att-resa-med-oss/betalning-och-biljetter/blue-card/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_bluecard_link_url','sv','SE','http://www.fritidsresor.se/att-resa-med-oss/betalning-och-biljetter/blue-card/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
Insert into STATIC_TEXT (KEY,LANG,COUNTRY,TEXT,CREATED_TS,CHANGED_TS) values ('mw_screen_ancillary_other_bluecard_link_url','nn','NO','http://www.startour.no/reise-med-star-tour/betaling-og-billetter/blue-card/',to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'),to_timestamp('25-FEB-16 02.29.06.807067000 PM','DD-MON-RR HH.MI.SSXFF AM'));
commit;