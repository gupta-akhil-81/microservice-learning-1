--------------------------------------------------------
--  File created - Thursday-April-21-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SM_SESSION
--------------------------------------------------------
	DROP TABLE SM_SESSION;
  CREATE TABLE "SM_SESSION" 
   (	"ID" NUMBER(10,0), 
	"SID" VARCHAR2(255 BYTE), 
	"CREATED" TIMESTAMP (6), 
	"EXPIRES" TIMESTAMP (6), 
	"CLIENT_INFO" VARCHAR2(255 BYTE), 
	"FULLNAME" VARCHAR2(255 BYTE), 
	"HOMETELE" VARCHAR2(15 BYTE), 
	"COMPTELE" VARCHAR2(15 BYTE), 
	"MOBILE" VARCHAR2(15 BYTE), 
	"EMAIL" VARCHAR2(255 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Index SYS_C0038470
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0038470" ON "SM_SESSION" ("SID") ;

--------------------------------------------------------
--  DDL for Index SYS_C0038471
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C0038471" ON "SM_SESSION" ("ID") ;

--------------------------------------------------------
--  Constraints for Table SM_SESSION
--------------------------------------------------------

  ALTER TABLE "SM_SESSION" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "SM_SESSION" MODIFY ("SID" NOT NULL ENABLE);
  ALTER TABLE "SM_SESSION" ADD PRIMARY KEY ("ID");
  ALTER TABLE "SM_SESSION" ADD UNIQUE ("SID");
--------------------------------------------------------
--  File created - Thursday-April-21-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SM_SESSION_RESOURCE
--------------------------------------------------------
	DROP TABLE SM_SESSION_RESOURCE;
  CREATE TABLE "SM_SESSION_RESOURCE" 
   (	"ID" NUMBER(10,0), 
	"RESOURCE_URL" VARCHAR2(512 BYTE)
   ) ;
--------------------------------------------------------
--  DDL for Index SM_SESSION_RESOURCE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SM_SESSION_RESOURCE_PK" ON "SM_SESSION_RESOURCE" ("ID", "RESOURCE_URL") ;
--------------------------------------------------------
--  Constraints for Table SM_SESSION_RESOURCE
--------------------------------------------------------

  ALTER TABLE "SM_SESSION_RESOURCE" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "SM_SESSION_RESOURCE" MODIFY ("RESOURCE_URL" NOT NULL ENABLE);
  ALTER TABLE "SM_SESSION_RESOURCE" ADD CONSTRAINT "SM_SESSION_RESOURCE_PK" PRIMARY KEY ("ID", "RESOURCE_URL");
  
--------------------------------------------------------
--  Ref Constraints for Table SM_SESSION_RESOURCE
--------------------------------------------------------

  ALTER TABLE "SM_SESSION_RESOURCE" ADD CONSTRAINT "SM_SESSION_RESOURCE_SM_SE_FK1" FOREIGN KEY ("ID")
	  REFERENCES "SM_SESSION" ("ID") ENABLE;
----Create Sequences for SessionID Sequence------------
CREATE SEQUENCE  "SESSIONIDSEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 4567 CACHE 20 NOORDER  NOCYCLE ;