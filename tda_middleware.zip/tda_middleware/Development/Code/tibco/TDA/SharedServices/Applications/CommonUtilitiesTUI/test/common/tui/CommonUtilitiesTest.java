package common.tui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.nio.charset.Charset;

import org.junit.Test;

public class CommonUtilitiesTest  {
	
	@Test
	public void testReplaceSpecialCharsWithUnicode() {
		assertEquals("Ashish", CommonUtilities.replaceSpecialCharsWithUnicode("Ashish", Charset.forName("UTF-8")));
	}
	
	@Test
	public void testTimestampToDateTime() {
		assertEquals("2014-02-27T14:14:41",CommonUtilities.timestampToDateTime(1393490681000L, "+5:30"));
	}
	
	@Test
	public void testDateTimeToTimestamp() {
		assertEquals(1393490681000L,CommonUtilities.dateTimeToTimestamp("2014-02-27T14:14:41"));
	}
	
	@Test
	public void testMd5Java() {
		assertEquals("263fb1aa85489991a2ef832ef10308a0",CommonUtilities.md5Java("This is an example."));
	}
	
	@Test
	public void testReplace() {
		assertEquals("My name is Ashish",CommonUtilities.replace("My name is -", "-", "Ashish"));
		
	}
	
	@Test
	public void testConvertToUsAscii() {
		assertEquals("eai_@",CommonUtilities.convertToUsAscii("���_@"));
	}
	
	@Test
	public void testremoveSplCharacters() {
		assertEquals("AoNang Krabi",CommonUtilities.removeSplCharacters("&(AoNang) (Krabi)"));
	}
	
	@Test
	public void testIsNull() {
		assertTrue(CommonUtilities.isNull(null));
		assertFalse(CommonUtilities.isNull("hello"));
	}
	
	@Test
	public void testWindDirectionDetails() {
		assertEquals("NORTHNORTHEAST", CommonUtilities.windDirectionDetails("33.33"));
	}
	
	@Test
	public void testWindDirection() {
		assertEquals("NORTHEAST", CommonUtilities.windDirection("33.33"));
	}
	
	@Test
	public void testConvertToMeasure() {
		assertEquals("6.0", Double.toString(CommonUtilities.convertToMeasure("12.8", "MPS", "BEAUFORT")));
	}
}