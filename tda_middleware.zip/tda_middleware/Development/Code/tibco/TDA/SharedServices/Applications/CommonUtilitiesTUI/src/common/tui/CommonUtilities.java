package common.tui;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.regex.Pattern;

public class CommonUtilities {

	/*
	 * DIRECTION-NORTH
	 */
	private static String NORTH = "NORTH";
	/*
	 * DIRECTION-EAST
	 */
	private static String EAST = "EAST";
	/*
	 * DIRECTION-WEST
	 */
	private static String WEST = "WEST";
	/*
	 * DIRECTION-SOUTH
	 */
	private static String SOUTH = "SOUTH";

	/*
	 * ERROR MESSAGES FOR WRONG INPUT
	 */

	private final static String Error_measure = " Measure 3 char code [For Beaufort :BEAUFORT or BFT] ,[Feet per sec(f/s): FPS ,Feet Per minute(f/min) : FTM] , [Kilometer Per Hour: KMH],[For knots; KNOT,KNOTS, KTS] ,[Meter per Mintue: MMI] ,[ Meter Per Hour: MPH], [Meter Per Sec(m/sec): MPS]";

	/*
	 * CURRENTLY SELECTED MEASURE TYPE
	 */
	private static String preferredFromMeasure = "KNOTS";
	/*
	 * WIND MEASURE INPUT
	 */
	private static double origanalValue = 0f;
	public static final String[][] HELP_STRINGS = {
			{
					"timestampToDateTime",
					"This method will take in timestamp in millisec and timezone"
							+ " and return corresponding date in '<YYYY-MM-dd>T<HH:mm:ss><timezone>' format."
							+ "\nIf timezone is not provided it will use current timezone.",
					"timestampToDateTime(1393490681000L, \"+5:30\"))",
					"2014-02-27T14:14:41" },
			{
					"dateTimeToTimestamp",
					"This method will take in date in string format and return milliseconds pertaining to that date and given timezone."
							+ "\nCurrent timezone will be taken if not provided explicitely.",
					"dateTimeToTimestamp(\"2014-02-27T14:14:41\")",
					"1393490681000" },
			{
					"md5Java",
					"This message will return unique 32bit MD5 hash-code for given string.",
					"md5Java(\"This is an example.\")",
					"263fb1aa85489991a2ef832ef10308a0" },
			{
					"convertToUsAscii",
					"This method remove from a String accented letters and replace them by their regular US ASCII equivalent.",
					"convertToUsAscii (\"���_@\")", "eai_@" },
			{
					"removeSplCharacters",
					"This method remove Special Character such as ()and & from String.",
					"removeSplCharacters(\"&(AoNang) (Krabi)\")", "AoNang Krabi" },
			{
					"replace",
					"This method will replace the part of string (target) with given string (replacement) in source.",
					"replace(\"Exempel p� tv�rumsl�genhet f�r 2�5 personer.\",\"�\",\"\\u2013\")",
					"Exempel p� tv�rumsl�genhet f�r 2\\u20135 personer." },
			{
						"isNull",
						"This method will check if the given object is null or not.",
						"isNull(obj)",
						"true" },
			{
					"replaceSpecialCharsWithUnicode",
					"This method will replace special characters in sourceString with their unicode as per given encoding",
					"replaceSpecialCharsWithUnicode(\"Legian B�ach Hotel\",\"StandardCharsets.UTF_8\")",
					"Legian B\u20ACach Hotel" },

			{ "windDirectionDetails",
					" Convert the wind degree direction to Cardinal Directions in detailed till 3 level like NORTH NORTH EAST OR EAST NORTH EAST etc.",
					" Example : windDirectionDetails(\"55.25\") ",
					" Returns:- String : \"NORTH NORTH EAST\"" },

			{ "windDirection",
					" Convert the wind degree direction to Cardinal Directions  till 2 level like NORTH  EAST OR EAST SOUTH etc.  ",
					" Example : String windDirection(\"55.25\") ",
					" Returns :String :  \"NORTH  EAST\"" },

			{ "convertToMeasure",
					" Convert the wind speed to specific measure value like knots to beaufor or meter per seconds to knots etc.  "
							+ "Excepted Code List, BFT-BEAUFORT, BEAUFORT-BEAUFORT, KTS-KNOTS"
							+ ", KNOTS-KNOTS, KNOT-KNOTS, FPS-FEET PER SEC, FPM-FEET PER MINUTE"
							+ ", MPM-METER PER MINUTE, MPS-METER PER SEC, MPH-METER PER HOURES	 "
							+ ", KMH-KILOMETER PER HOURS",
					" Example : convertToMeasure(\"5\", \"mps\", \"knot\"); ",
					" Returns : double  :  13.606911063194275 " },
			{ "appendStrings",
					" appned more than one string \n return String appendStrings(String @list of string)   ",
					" Example : String appendStrings(\"string1\", \",\", \"string2\", \",\", \"string3\"); ",
					" Returns :  string1,string2,string3" } };
	public static void main(String[] args) {
		// String obj = null;
		System.out.println(isNull(""));
		System.out.println("Exempel p� tv�rumsl�genhet f�r 2�5 personer.");
		System.out.println(replace("Exempel p� tv�rumsl�genhet f�r 2�5 personer.", "�", "\\u2013"));
		System.out.println(replace("Exempel p� tv�rumsl�genhet f�r 2\u20135 personer.", "\\u2013", "�"));

		System.out.println(timestampToDateTime(1393490681000L, "+5:30"));
		System.out.println(dateTimeToTimestamp("2014-02-27T14:14:41"));
		System.out.println(md5Java("This is an example."));
		System.out.println("Wind Measure Converted Test : " + convertToMeasure("12.8", "MPS", "BEAUFORT"));
		System.out.println("Wind Direction 2 level Test : " + windDirection("33.33"));
		System.out.println("Wind Direction 3 level Test : " + windDirectionDetails("33.33"));
		System.out.println("Append Strings  : " + appendStrings("string1", ",", "string2", ",", "string3"));
		
	}

	/**
	 * This method will replace special characters in sourceString with their
	 * unicode as per given encoding
	 * 
	 * @param sourceString
	 * @param encoding
	 * @return
	 */
	public static String replaceSpecialCharsWithUnicode(String sourceString,
			Charset encoding) {

		String finalText = "";
		char[] charArray = sourceString.toCharArray();
		String ch = null;
		//Set specialChars = new HashSet<String>();

		if (charArray != null && charArray.length > 0) {
			for (int i = 0; i < charArray.length; i++) {
				// checking size of character
				ch = Character.toString(charArray[i]);

				try {
					if (ch.getBytes(encoding).length > 2) {
						//specialChars.add(ch);
						ch = "\\u" + returnUnicode(charArray[i]);
						finalText = finalText + ch;
					} else {
						finalText = finalText + charArray[i];
					}
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		// System.out.println(finalText);
		return finalText;
	}

	/**
	 * program to return unicode
	 * 
	 * @param ch
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private static String returnUnicode(char ch)
			throws UnsupportedEncodingException {

		// Convert the integer to a hexadecimal code.
		String hexCode = Integer.toHexString(ch).toUpperCase();

		// but the it must be a four number value.
		String hexCodeWithAllLeadingZeros = "0000" + hexCode;
		String hexCodeWithLeadingZeros = hexCodeWithAllLeadingZeros
				.substring(hexCodeWithAllLeadingZeros.length() - 4);

		return hexCodeWithLeadingZeros;
	}

	/**
	 * Java 7 Program to read file in given encoding
	 * 
	 * @param path
	 * @param encoding
	 * @return
	 * @throws IOException
	 */
	protected static String readFile(String path, Charset encoding)
			throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return encoding.decode(ByteBuffer.wrap(encoded)).toString();
	}

	/**
	 * This method will take in timestamp in millisec and timezone and return
	 * corresponding date in '<YYYY-MM-dd>T<HH:mm:ss><timezone>' format. If
	 * timezone is not provided it will use current timezone.
	 * 
	 * @param timestampInMs
	 * @param timezone
	 * @return
	 */
	public static String timestampToDateTime(long timestampInMs, String timezone) {

		StringBuilder sb = new StringBuilder();

		DateFormat formatter = new SimpleDateFormat("YYYY-MM-dd");

		if (timezone == null) {
			formatter.setTimeZone(TimeZone.getTimeZone("GMT" + timezone));
		} else {
			Calendar c = new GregorianCalendar();
			formatter.setTimeZone(c.getTimeZone());
		}

		sb.append(formatter.format(new Date(timestampInMs)));

		formatter = new SimpleDateFormat("HH:mm:ss");
		formatter.setTimeZone(TimeZone.getTimeZone("GMT" + timezone));
		sb.append("T");
		sb.append(formatter.format(new Date(timestampInMs)));

		return sb.toString();
	}

	/**
	 * This method will take in date in string format and return milliseconds
	 * pertaining to that date and given locale. Current locale will be taken if
	 * not provided.
	 * 
	 * @param date
	 * @return
	 */

	public static long dateTimeToTimestamp(String date) {

		long returnTime = 0L;

		if (date != null && (date.contains("+") || date.contains("-"))) {

			String[] arr = null;

			String timezone = null;
			String datePart = null;
			String time = null;

			arr = date.split("T", 2);

			if (arr != null && arr.length > 1) {
				datePart = arr[0];
				String temp = arr[1];

				if (temp.contains("+")) {
					arr = temp.split("+", 2);

					if (arr != null && arr.length > 1) {
						time = arr[0];
						timezone = "+" + arr[1];
					} else if (arr != null) {
						time = arr[0];
						// timezone = "local";
					}
				} else {
					arr = temp.split("-", 2);

					if (arr != null && arr.length > 1) {
						time = arr[0];
						timezone = "-" + arr[1];
					} else if (arr != null) {
						time = arr[0];
						// timezone = "local";
					}
				}

			}

			/*
			 * System.out.println("inside if");
			 * System.out.println("datePart:"+datePart);
			 * System.out.println("time:"+time);
			 * System.out.println("timezone:"+timezone);
			 */

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			if (timezone != null) {
				dateFormat.setTimeZone(TimeZone.getTimeZone("GMT" + timezone));
			} else {
				Calendar c = new GregorianCalendar();
				dateFormat.setTimeZone(c.getTimeZone());
			}

			Date convertedDate = null;

			try {
				convertedDate = dateFormat.parse(datePart + " " + time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			returnTime = convertedDate.getTime();
			// new Timestamp(returnTime);
		}

		return returnTime;
	}

	/**
	 * This message will return unique 32bit MD5 hash-code for given string.
	 * 
	 * @param message
	 * @return
	 */
	public static String md5Java(String message) {
		String digest = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] hash = md.digest(message.getBytes("UTF-8"));
			// converting byte array to Hexadecimal String
			StringBuilder sb = new StringBuilder(2 * hash.length);
			for (byte b : hash) {
				sb.append(String.format("%02x", b & 0xff));
			}

			digest = sb.toString();
		} catch (UnsupportedEncodingException ex) {
			ex.printStackTrace();
		} catch (NoSuchAlgorithmException ex) {
			ex.printStackTrace();
		}
		return digest;
	}

	
	/**
	 * This method will replace the part of string (target) with given string
	 * (replacement) in source
	 * 
	 * @param sourceString
	 * @param stringToReplace
	 * @param replacementString
	 * @return
	 */
	public static String replace(String source, String target,
			String replacement) {

		return replaceAll(target, replacement, source, false);
	}

	/**
	 * This is a private method and will not be exposed but utilized by other
	 * methods
	 * 
	 * @param findtxt
	 * @param replacetxt
	 * @param str
	 * @param isCaseInsensitive
	 * @return
	 */
	private static String replaceAll(String findtxt, String replacetxt,
			String str, boolean isCaseInsensitive) {
		if (str == null) {
			return null;
		}
		if (findtxt == null || findtxt.length() == 0) {
			return str;
		}
		if (findtxt.length() > str.length()) {
			return str;
		}
		int counter = 0;
		String thesubstr = "";
		while ((counter < str.length())
				&& (str.substring(counter).length() >= findtxt.length())) {
			thesubstr = str.substring(counter, counter + findtxt.length());
			if (isCaseInsensitive) {
				if (thesubstr.equalsIgnoreCase(findtxt)) {
					str = str.substring(0, counter) + replacetxt
							+ str.substring(counter + findtxt.length());
					// Failing to increment counter by replacetxt.length()
					// leaves you open
					// to an infinite-replacement loop scenario: Go to replace
					// "a" with "aa" but
					// increment counter by only 1 and you'll be replacing 'a's
					// forever.
					counter += replacetxt.length();
				} else {
					counter++; // No match so move on to the next character from
								// which to check for a findtxt string match.
				}
			} else {
				if (thesubstr.equals(findtxt)) {
					str = str.substring(0, counter) + replacetxt
							+ str.substring(counter + findtxt.length());
					counter += replacetxt.length();
				} else {
					counter++;
				}
			}
		}
		return str;
	}

	/**
	 * MethodName: convertToUsAscii
	 * 
	 * This method remove from a String accented letters and replace them by
	 * their regular US ASCII equivalent. Example convertToUsAscii (����_@�)
	 * Return : eai_@
	 */
	public static String convertToUsAscii(String s) {
		String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
		Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
		return pattern.matcher(temp).replaceAll("");
	}
	/**
	 * MethodName: removeSplCharacters
	 * 
	 * This method remove Special Character such as ()and & from String. Example
	 * removeSplCharacters(�&(AoNang) (Krabi)�) Return : AoNang Krabi
	 * 
	 */
	public static String removeSplCharacters(String number) {
		// System.out.println("Final Number is:::"+number.replaceAll("[^a-zA-Z 0-9]+",""));
		return number.replaceAll("[()&]+/", "");
	}
	
	/**
	 * this method checks whether given object is null or not.
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isNull(Object obj){
		return (obj==null);
	}

	/**
	 * wind data measurement Documentation for TIBCO has been created also
	 */

	/**
	 * windDirectionDetails Convert wind speed from degree to detailed
	 * cardinals.
	 * 
	 * For example : wind speed 22.5 should be convert into North North
	 * East(NNE)
	 * 
	 * @param windDegreesDirection
	 * @return detailedCardinals
	 * 
	 * 
	 */
	public static String windDirectionDetails(String windDegreesDirection) {

		String[] caridnals_full = { NORTH, appendStrings(NORTH, NORTH, EAST), appendStrings(NORTH, EAST),
				appendStrings(EAST, NORTH, EAST), EAST, appendStrings(EAST, SOUTH, EAST), appendStrings(SOUTH, EAST),
				appendStrings(SOUTH, SOUTH, EAST), SOUTH, appendStrings(SOUTH, SOUTH, WEST), appendStrings(SOUTH, WEST),
				appendStrings(WEST, SOUTH, WEST), WEST, appendStrings(WEST, NORTH, WEST), appendStrings(NORTH, WEST),
				appendStrings(NORTH, NORTH, WEST), NORTH };

		String windDirection = "";
		if (windDegreesDirection != null && windDegreesDirection.length() > 0) {
			float windDegreeInFloat = Float.valueOf(windDegreesDirection);
			windDegreeInFloat = windDegreeInFloat * 10;
			windDirection = caridnals_full[(int) Math.round(((float) windDegreeInFloat % 3600) / 225)];
			return windDirection;
		}

		return windDirection;
	}

	public static String appendStrings(String... arg) {
		StringBuffer finalStr = new StringBuffer();
		for (String s : arg) {
			finalStr.append(s);
		}
		return finalStr.toString();
	}

	/**
	 * windDirection
	 *
	 * Convert wind speed from degree to cardinals.
	 * 
	 * For example : wind speed 22.5 should be convert into North East(NE)
	 * 
	 * @param windDegreesDirection
	 * @return cardinal
	 * 
	 * 
	 */

	public static String windDirection(String windDegreesDirection) {

		String[] caridnals_full = { NORTH, appendStrings(NORTH, EAST), EAST, appendStrings(SOUTH, EAST), SOUTH,
				appendStrings(SOUTH, WEST), WEST, appendStrings(NORTH, WEST), NORTH };
		String windDirection = "";
		if (windDegreesDirection != null && windDegreesDirection.length() > 0) {
			float windDegreeInFloat = Float.valueOf(windDegreesDirection);
			windDirection = caridnals_full[(int) Math.round(((float) windDegreeInFloat % 360) / 45)];
			return windDirection;
		}
		return windDirection;
	}

	/**
	 * 
	 * @param _valueForMeasure
	 * @param _measureFromString
	 * @param _measureToString
	 * @return String
	 */
	public static double convertToMeasure(String _valueForMeasure, String _measureFromString, String _measureToString) {
		try {
			if (_measureToString == null || _measureToString.length() <= 0) {
				throw new NullPointerException(
						" To measure value can not be Null or empty. It must be as " + Error_measure.toString());
			} else if (_measureFromString == null || _measureFromString.length() <= 0) {
				throw new NullPointerException(
						" From measure value can not be Null or empty. It must be as " + Error_measure.toString());
			} else if (_valueForMeasure == null || _valueForMeasure.length() <= 0)
				throw new NullPointerException(
						" Input Value of variable(_valueForMeasure) can not be Null or empty. it must be a valid number string for example : 1.0 or 1 as string ");

			if (_valueForMeasure != null && _valueForMeasure.length() > 0) {
				origanalValue = Float.valueOf(_valueForMeasure);
			}

			if (_measureToString.length() >= 3 || _measureFromString.length() >= 3) {
				_measureFromString = _measureFromString.toUpperCase();
				_measureToString = _measureToString.toUpperCase();
			}

			if (_measureFromString != null) {
				setPreferredMeasure(_measureFromString);
				origanalValue = convertToKnot(origanalValue, preferredFromMeasure);
			}

			setPreferredMeasure(_measureToString);

			return convertTo(preferredFromMeasure);
		} catch (IllegalArgumentException ex) {

			throw new IllegalArgumentException("Input value in Method : Value: "+_valueForMeasure +" From : "+_measureFromString+ " To: "+ _measureToString +"can't calculate measure other than these " + Error_measure.toString());

		}
	}

	/**
	 * 
	 * @param _measure
	 * @return
	 */

	private static double convertTo(final String _measure) {

		String convert = "";

		final double v = origanalValue; // always Knots!!!

		final double ms = v * 0.514444f; // m s-1

		final double knot = v; // knots

		final double fts = (v * 1.687810f); // ft s-1

		final double ftm = (fts * 60.f); // ft min-1

		switch (_measure) {

		case "MPS":
			convert = String.valueOf(ms);
			break;
		case "KMH":
			final double kmh = v * 1.852f; // km/h
			convert = String.valueOf(kmh);
			break;
		case "KNOTS":
			convert = String.valueOf(knot);
			break;
		case "KTS":
			convert = String.valueOf(knot);
			break;
		case "KNOT":
			convert = String.valueOf(knot);
			break;
		case "MPH":
			final double mph = v * 1.150779f; // mi h-1
			convert = String.valueOf(mph);
			break;
		case "FPS":
			convert = String.valueOf(fts);
			break;
		case "MPM":
			final double mmi = (ms * 60.f); // m min-1
			convert = String.valueOf(mmi);
			break;
		case "FPM":
			convert = String.valueOf(ftm);
			break;
		case "BEAUFORT":
			final int beaufort = knotToBeaufort(knot);
			convert = String.valueOf(beaufort);
			break;
		case "BFT":
			final int bft = knotToBeaufort(knot);
			convert = String.valueOf(bft);
			break;
		default:
			throw new IllegalArgumentException("unknown Measure" + _measure);
		}
		// return convert + "_" + preferredFromMeasure;

		return Double.valueOf(convert);
	}

	/**
	 * 
	 * @param value
	 * @param _measure
	 * @return
	 */
	private static double convertToKnot(double value, final String _measure) {
		double convertToKnot = 0.f;

		final double v = value; // always Knots!!!
		switch (_measure) {

		case "MPS":
			final double ms = v * 1.9438444924574f; // m s-1
			convertToKnot = ms;
			break;
		case "KMH":
			final double kmh = v * 0.53995680389235f; // km/h
			convertToKnot = kmh;
			break;
		case "KNOTS":
			final double knot = v; // knots
			convertToKnot = knot;
			break;
		case "KTS":
			final double kts = v; // knots
			convertToKnot = kts;
			break;
		case "KNOT":
			final double knoot = v; // knots
			convertToKnot = knoot;
			break;
		case "MPH":
			final double mph = v * 0.86897624190816f; // mi h-1
			convertToKnot = mph;
			break;
		case "FPS":
			final double fts = (v * 0.59248380130101F); // ft s-1
			convertToKnot = fts;
			break;
		case "MPM":
			final double mmi = (v * 0.032397408207688f); // m min-1
			convertToKnot = mmi;
			break;
		case "FPM":
			final double ftm = (v * 0.0098747300216836f);
			convertToKnot = ftm;
			break;
		case "BEAUFORT":
			convertToKnot = beaufortToKnot(origanalValue);
		case "BFT":
			convertToKnot = beaufortToKnot(origanalValue);
			break;
		default:
			throw new IllegalArgumentException("unknown Measure" + _measure);
		}

		return convertToKnot;
	}

	/**
	 * This method will be used privately to convert knot values to beaufort.
	 * 
	 * @param _knots
	 * @return integer values in beaufort from knot
	 */
	private static int knotToBeaufort(final double _knots) {

		if (_knots <= 1) {
			return 0;
		}
		if (_knots > 1 && _knots < 3.5) {
			return 1;
		}
		if (_knots >= 3.5 && _knots < 6.5) {
			return 2;
		}
		if (_knots >= 6.5 && _knots < 10.5) {
			return 3;
		}
		if (_knots >= 10.5 && _knots < 16.5) {
			return 4;
		}
		if (_knots >= 16.5 && _knots < 21.5) {
			return 5;
		}
		if (_knots >= 21.5 && _knots < 27.5) {
			return 6;
		}
		if (_knots >= 27.5 && _knots < 33.5) {
			return 7;
		}
		if (_knots >= 33.5 && _knots < 40.5) {
			return 8;
		}
		if (_knots >= 40.5 && _knots < 47.5) {
			return 9;
		}
		if (_knots >= 47.5 && _knots < 55.5) {
			return 10;
		}
		if (_knots >= 55.5 && _knots < 63.5) {
			return 11;
		}
		if (_knots >= 63.5 && _knots < 74.5) {
			return 12;
		}
		if (_knots >= 74.5 && _knots < 80.5) {
			return 13;
		}
		if (_knots >= 80.5 && _knots < 89.5) {
			return 14;
		} else if (_knots >= 89.5) {
			return 15;
		}
		return -1;
	}

	/**
	 * Set preferred measure of wind speed.
	 * 
	 * @param _preferredMeasure
	 * @throws IllegalArgumentException
	 *             if measure not supported
	 * @see #getMeasure()
	 * @see #getSupportedMeasure()
	 */
	private static void setPreferredMeasure(final String _preferredMeasure) throws IllegalArgumentException {
		if (_preferredMeasure == null) {
			throw new NullPointerException("Preferred Measure");
		}

		preferredFromMeasure = _preferredMeasure;
	}

	/**
	 * This method will be privately used for converting beaufort to know for
	 * base values
	 * 
	 * @param _beaufort
	 * @return double value in knot from beaufort
	 */
	private static double beaufortToKnot(double _beaufort) {
		int bf = Double.valueOf(_beaufort).intValue();
		int beaufortToKnots = 0;
		if (_beaufort > 12)
			System.out.println("Invalid measurement.");
		else if (_beaufort <= 0)
			System.out.println("Invalid measurement.");
		else
			System.out.println("The wind speed is: " + _beaufort + "Knots.");
		switch (bf) {
		case 0:
			beaufortToKnots = 0;
			break;
		case 1:
			beaufortToKnots = (1 + 3) / 2;
			break;
		case 2:
			beaufortToKnots = (4 + 6) / 2;
			break;
		case 3:
			beaufortToKnots = (7 + 10) / 2;
			beaufortToKnots = beaufortToKnots + 1;
			break;
		case 4:
			beaufortToKnots = (11 + 16) / 2;
			break;
		case 5:
			beaufortToKnots = (17 + 21) / 2;
			break;
		case 6:
			beaufortToKnots = (22 + 27) / 2;
			break;
		case 7:
			beaufortToKnots = (28 + 33) / 2;
			break;
		case 8:
			beaufortToKnots = (34 + 40) / 2;
			break;
		case 9:
			beaufortToKnots = (41 + 47) / 2;
			break;
		case 10:
			beaufortToKnots = (48 + 55) / 2;
			beaufortToKnots = beaufortToKnots + 1;
			break;
		case 11:
			beaufortToKnots = (56 + 63) / 2;
			beaufortToKnots = beaufortToKnots + 1;
			break;
		case 12:
			beaufortToKnots = (64 + 64) / 2;
			break;
		default:
			break;
		}
		return beaufortToKnots;
	}

}
