package com.emiratesnbd.forex.currencies.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.emiratesnbd.forex.currencies.models.Currencies;
import com.emiratesnbd.forex.currencies.models.Currency;
import com.emiratesnbd.forex.currencies.repositories.CurrencyRepository;

@RestController
public class ForexCurrenciesRestController {

	@Autowired
	private CurrencyRepository  currencyRepository;
	
	public ForexCurrenciesRestController() {
		
	}
	
	@GetMapping(path="/currencies/{alphaCode}")
	public Currency getCurrencyByAlphaCode(@PathVariable String alphaCode) {
		
		Currency cur=currencyRepository.findByAlphaCode(alphaCode);
		return cur;
	}
	
	@GetMapping(path="/currencies")
	public Currencies getCurrencies() {
		
		Currencies currencies=new Currencies();
		currencies.setCurrencies(currencyRepository.findAll());
		return currencies;
	}
	
	@PostMapping(path="/currencies")
	public void postCurrency(@RequestBody Currency currency) {
		
		currencyRepository.save(currency);
	}
	
	@PutMapping(path="/currencies/{alphaCode}")
	public void putCurrency(@RequestBody Currency currency, @PathVariable String alphaCode) {
		
		currencyRepository.save(currency);
	}
	
	@DeleteMapping(path="/currencies/{alphaCode}")
	public void deleteCurrency(@PathVariable String alphaCode) {
		
		currencyRepository.deleteById(alphaCode);
	}

}
