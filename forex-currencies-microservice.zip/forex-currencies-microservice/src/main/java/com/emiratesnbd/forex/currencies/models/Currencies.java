package com.emiratesnbd.forex.currencies.models;

import java.util.List;


public class Currencies {

	private List<Currency> currencies;

	public List<Currency> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(List	<Currency> currencies) {
		this.currencies = currencies;
	}
	
	

}
