package com.emiratesnbd.forex.currencies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForexCurrenciesMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForexCurrenciesMicroserviceApplication.class, args);
	}
}
