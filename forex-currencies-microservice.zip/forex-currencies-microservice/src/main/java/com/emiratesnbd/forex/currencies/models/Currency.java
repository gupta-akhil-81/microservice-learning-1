package com.emiratesnbd.forex.currencies.models;

import java.math.BigDecimal;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "currency")
public class Currency {

	@Id
	private String alphaCode;
	private BigDecimal numCode;
	private BigDecimal minorUnit;
	private String name;

	public String getAlphaCode() {
		return alphaCode;
	}

	public void setAlphaCode(String alphaCode) {
		this.alphaCode = alphaCode;
	}

	public BigDecimal getNumCode() {
		return numCode;
	}

	public void setNumCode(BigDecimal numCode) {
		this.numCode = numCode;
	}

	public BigDecimal getMinorUnit() {
		return minorUnit;
	}

	public void setMinorUnit(BigDecimal minorUnit) {
		this.minorUnit = minorUnit;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
