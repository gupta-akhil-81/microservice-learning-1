package com.emiratesnbd.forex.currencies.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.emiratesnbd.forex.currencies.models.Currency;


public interface CurrencyRepository extends MongoRepository<Currency, String> {

	@Query(value = "{ 'alphaCode' : ?0}")
	public Currency findByAlphaCode(String alphaCode);

}