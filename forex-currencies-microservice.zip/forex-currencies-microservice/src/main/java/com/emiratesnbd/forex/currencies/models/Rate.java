package com.emiratesnbd.forex.currencies.models;

import org.springframework.data.mongodb.core.mapping.Document;

public class Rate {

	private String alphaCode;
	private String name;
	private double customerBuy;
	private double customerSell;
	private double apoSell;
	private double apoBuy;
	private double parBuy;
	private double parSell;
	private double cashBuy;
	private double cashSell;
	private double masterCardBuy;
	private double masterCardSell;
	private double baseSell;
	private double baseBuy;
	private double preferentialRate;
	private double midRate;
	
	public String getAlphaCode() {
		return alphaCode;
	}
	public void setAlphaCode(String alphaCode) {
		this.alphaCode = alphaCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCustomerBuy() {
		return customerBuy;
	}
	public void setCustomerBuy(double customerBuy) {
		this.customerBuy = customerBuy;
	}
	public double getCustomerSell() {
		return customerSell;
	}
	public void setCustomerSell(double customerSell) {
		this.customerSell = customerSell;
	}
	public double getApoSell() {
		return apoSell;
	}
	public void setApoSell(double apoSell) {
		this.apoSell = apoSell;
	}
	public double getApoBuy() {
		return apoBuy;
	}
	public void setApoBuy(double apoBuy) {
		this.apoBuy = apoBuy;
	}
	public double getParBuy() {
		return parBuy;
	}
	public void setParBuy(double parBuy) {
		this.parBuy = parBuy;
	}
	public double getParSell() {
		return parSell;
	}
	public void setParSell(double parSell) {
		this.parSell = parSell;
	}
	public double getCashBuy() {
		return cashBuy;
	}
	public void setCashBuy(double cashBuy) {
		this.cashBuy = cashBuy;
	}
	public double getCashSell() {
		return cashSell;
	}
	public void setCashSell(double cashSell) {
		this.cashSell = cashSell;
	}
	public double getMasterCardBuy() {
		return masterCardBuy;
	}
	public void setMasterCardBuy(double masterCardBuy) {
		this.masterCardBuy = masterCardBuy;
	}
	public double getMasterCardSell() {
		return masterCardSell;
	}
	public void setMasterCardSell(double masterCardSell) {
		this.masterCardSell = masterCardSell;
	}
	public double getBaseSell() {
		return baseSell;
	}
	public void setBaseSell(double baseSell) {
		this.baseSell = baseSell;
	}
	public double getBaseBuy() {
		return baseBuy;
	}
	public void setBaseBuy(double baseBuy) {
		this.baseBuy = baseBuy;
	}
	public double getPreferentialRate() {
		return preferentialRate;
	}
	public void setPreferentialRate(double preferentialRate) {
		this.preferentialRate = preferentialRate;
	}
	public double getMidRate() {
		return midRate;
	}
	public void setMidRate(double midRate) {
		this.midRate = midRate;
	}

	
	
}
